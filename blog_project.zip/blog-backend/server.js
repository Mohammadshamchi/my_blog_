const express = require("express");
const bodyParser = require("body-parser");
const mongoose = require("mongoose");
const app = express();
const userRoutes = require("./routes/users");
const postRoutes = require("./routes/posts");
const categoryRoutes = require("./routes/categories");
const commentRoutes = require("./routes/comments");
const cors = require("cors");
// Middleware
app.use(bodyParser.json());
app.use(express.json());
app.use("/api/users", userRoutes);
app.use("/api/posts", postRoutes);
app.use("/api/categories", categoryRoutes);
app.use("/api/comments", commentRoutes);
// Connect to MongoDB (you'll need to have MongoDB set up locally or use a service like MongoDB Atlas)

// Basic route for testing
app.get("/", (req, res) => {
  res.send("Blog Backend is running!");
});

const port = 3000;
app.listen(port, () => {
  console.log(`Server started on http://localhost:${port}`);
});

const connectionString =
  "mongodb+srv://am0hii:ay1YWz6K3PbHar92@cluster0.cu48b.mongodb.net/?retryWrites=true&w=majority"; // Replace with your AWS MongoDB connection string

mongoose
  .connect(connectionString, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  })
  .then(() => console.log("Connected to MongoDB"))
  .catch((err) => console.error("Could not connect to MongoDB", err));

app.use(cors({ origin: "http://localhost:3000" }));
