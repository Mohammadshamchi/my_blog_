const express = require("express");
const router = express.Router();
const Category = require("../models/Category");

// Get all categories
router.get("/", async (req, res) => {
  try {
    const categories = await Category.find();
    res.json(categories);
  } catch (err) {
    res.status(500).send("Server error");
  }
});

// Create a new category
router.post("/", async (req, res) => {
  try {
    const newCategory = new Category(req.body);
    const category = await newCategory.save();
    res.json(category);
  } catch (err) {
    res.status(500).send("Server error");
  }
});

// Similarly, more routes can be added as needed

module.exports = router;
