const express = require("express");
const router = express.Router();
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");

const User = require("../models/User");

// Register a new user
router.post("/register", async (req, res) => {
  try {
    // Check if user already exists
    let user = await User.findOne({ username: req.body.username });
    if (user) return res.status(400).send("User already exists");

    // Hash password
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(req.body.password, salt);

    // Create new user
    user = new User({
      username: req.body.username,
      password: hashedPassword,
    });
    await user.save();

    res.send("User registered successfully");
  } catch (err) {
    res.status(500).send("Server error");
  }
});

// User login
router.post("/login", async (req, res) => {
  try {
    // Check if user exists
    const user = await User.findOne({ username: req.body.username });
    if (!user) return res.status(400).send("Invalid credentials");

    // Check password
    const validPassword = await bcrypt.compare(
      req.body.password,
      user.password
    );
    if (!validPassword) return res.status(400).send("Invalid credentials");
    // View Profile
    router.get("/profile/:userId", async (req, res) => {
      try {
        const user = await User.findById(req.params.userId).select("-password");
        if (!user) return res.status(404).send("User not found");
        res.json(user);
      } catch (err) {
        res.status(500).send("Server error");
      }
    });
    // Update Profile
    router.put("/profile/:userId", async (req, res) => {
      try {
        let user = await User.findById(req.params.userId);
        if (!user) return res.status(404).send("User not found");

        // Here, you can update the fields like email, profilePicture, bio, etc.
        if (req.body.email) user.email = req.body.email;
        if (req.body.bio) user.bio = req.body.bio;
        // ... add other fields as needed

        await user.save();

        res.json(user);
      } catch (err) {
        res.status(500).send("Server error");
      }
    });

    // Generate JWT token
    const token = jwt.sign(
      { userId: user.id, role: user.role },
      "@appleIphone5s@",
      {
        expiresIn: "1h",
      }
    ); // Replace 'SECRET_KEY' with a strong secret key

    res.json({ token });
  } catch (err) {
    res.status(500).send("Server error");
  }
});

module.exports = router;
