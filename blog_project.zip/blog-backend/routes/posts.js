const express = require("express");
const router = express.Router();
const Post = require("../models/Post");
const multer = require("multer");

// Get all posts
router.get("/", async (req, res) => {
  try {
    const posts = await Post.find();
    res.json(posts);
  } catch (err) {
    res.status(500).send("Server error");
  }
});

// Create a new post
router.post("/", async (req, res) => {
  try {
    const newPost = new Post(req.body);
    const post = await newPost.save();
    res.json(post);
  } catch (err) {
    res.status(500).send("Server error");
  }
});
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, "./uploads/");
  },
  filename: function (req, file, cb) {
    cb(null, Date.now() + "-" + file.originalname);
  },
});

const upload = multer({ storage: storage });
router.post("/", upload.single("image"), async (req, res) => {
  try {
    const newPost = new Post({
      title: req.body.title,
      content: req.body.content,
      author: req.body.author, // You'll need to adjust this based on your setup
      imageUrl: req.file.path,
    });
    const post = await newPost.save();
    res.json(post);
  } catch (err) {
    res.status(500).send("Server error");
  }
});

// More routes can be added for updating, deleting posts, etc.

module.exports = router;
