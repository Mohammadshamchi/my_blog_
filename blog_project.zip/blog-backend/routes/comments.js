const express = require("express");
const router = express.Router();
const Comments = require("../models/Comments");

// Get all categories
router.get("/", async (req, res) => {
  try {
    const categories = await Comments.find();
    res.json(categories);
  } catch (err) {
    res.status(500).send("Server error");
  }
});

// Create a new comments
router.post("/", async (req, res) => {
  try {
    const newComments = new Comments(req.body);
    const comments = await newComments.save();
    res.json(comments);
  } catch (err) {
    res.status(500).send("Server error");
  }
});

// Similarly, more routes can be added as needed

module.exports = router;
