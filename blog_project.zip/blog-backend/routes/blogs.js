const { authenticate, authorizeAdmin } = require("../middleware/auth");

// ...

// Add a new blog (only for authenticated users)
router.post("/", authenticate, async (req, res) => {
  // ... rest of the code
});
router.post("/", [authenticate, authorizeAdmin], async (req, res) => {
  // ... rest of the code
});
