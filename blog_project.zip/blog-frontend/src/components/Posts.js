import React, { useState, useEffect } from "react";
import api from "../services/api";

function Posts() {
  const [posts, setPosts] = useState([]);

  useEffect(() => {
    async function fetchData() {
      try {
        const response = await api.get("/posts"); // Note we're using 'api' here
        setPosts(response.data);
      } catch (error) {
        console.error("Error fetching posts:", error);
      }
    }

    fetchData();
  }, []);

  return <div>{/* Render your posts here */}</div>;
}

export default Posts;
