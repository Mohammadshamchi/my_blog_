import React from "react";

function BlogPage() {
  return (
    <div className="p-4">
      <h1 className="text-3xl font-bold mb-4">Blog Title</h1>
      <p className="text-gray-700 mb-8">Blog content goes here...</p>
      <h2 className="text-2xl font-semibold mb-4">Comments</h2>
      {/* Iterate through comments and display them here */}
    </div>
  );
}

export default BlogPage;
