import React, { useEffect, useState } from "react";
import axios from "axios";
// blog-frontend/src/components/HomePage.js

import BlogList from "./BlogList";

function HomePage() {
  const [posts, setPosts] = useState([]);

  useEffect(() => {
    axios
      .get("http://localhost:3000/api/posts")
      .then((response) => {
        setPosts(response.data);
      })
      .catch((error) => {
        console.error("There was an error fetching the posts!", error);
      });
  }, []);

  return (
    <div>
      <h1>Welcome to My Blog</h1>
      <BlogList />
      {posts.map((post) => (
        <div key={post._id}>
          <h2>{post.title}</h2>
          <img
            src={`http://localhost:3000/${post.imageUrl}`}
            alt={post.title}
          />
          <p>{post.content}</p>
        </div>
      ))}
    </div>
  );
}

export default HomePage;
