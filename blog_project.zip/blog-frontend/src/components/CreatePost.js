import axios from "axios";
import { useState } from "react";

const [title, setTitle] = useState("");
const [content, setContent] = useState("");
const [image, setImage] = useState(null);

function CreatePost() {
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [image, setImage] = useState(null);

  const handleSubmit = async (e) => {
    e.preventDefault();

    const formData = new FormData();
    formData.append("title", title);
    formData.append("content", content);
    formData.append("image", image);

    try {
      const response = await axios.post(
        "http://localhost:3000/api/posts",
        formData
      );
      console.log(response.data);
    } catch (error) {
      console.error("Error creating post:", error);
    }
  };

  return (
    <div>
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          placeholder="Title"
        />
        <textarea
          value={content}
          onChange={(e) => setContent(e.target.value)}
          placeholder="Content"
        ></textarea>
        <input type="file" onChange={(e) => setImage(e.target.files[0])} />
        <button type="submit">Create Post</button>
      </form>
    </div>
  );
}

const handleSubmit = (e) => {
  e.preventDefault();
  const formData = new FormData();
  formData.append("title", title);
  formData.append("content", content);
  formData.append("image", image);

  axios
    .post("http://localhost:3000/api/posts", formData)
    .then((response) => {
      console.log("Post created:", response.data);
    })
    .catch((error) => {
      console.error("Error creating post:", error);
    });
};

// return (
//   <form onSubmit={handleSubmit}>
//     <input
//       type="text"
//       value={title}
//       onChange={(e) => setTitle(e.target.value)}
//       placeholder="Title"
//     />
//     <textarea
//       value={content}
//       onChange={(e) => setContent(e.target.value)}
//       placeholder="Content"
//     ></textarea>
//     <input type="file" onChange={(e) => setImage(e.target.files[0])} />
//     <button type="submit">Create Post</button>
//   </form>
// );

export default CreatePost;
